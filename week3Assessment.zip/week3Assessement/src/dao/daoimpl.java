package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import customexception.exception;
import model.Scholar;
import util.getConnection;

public class daoimpl implements absdao {

//	public daoimpl() {
//		// TODO Auto-generated constructor stub
//	}
	public List<Scholar> ListAllScholars() throws  SQLException, ClassNotFoundException
	{
		ArrayList<Scholar> lis1=new ArrayList<>();
		Connection con=getConnection.getConnections();
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery("select * from Scholar");
		while(rs.next())
		{
			Scholar scholar =new Scholar();
			scholar.setScholarId(rs.getInt(1));
			scholar.setName(rs.getString(2));
			scholar.setEmail(rs.getString(3));
			scholar.setMobile(rs.getString(4));
			lis1.add(scholar);
		}
		return lis1;
		
	
	}
	public Scholar GetOneScholar(Integer scholarId) throws ClassNotFoundException, SQLException, exception
	{
		Connection con=getConnection.getConnections();
		PreparedStatement st=con.prepareStatement("select * from Scholar where Rollno=(?)");
		st.setInt(1,scholarId);
		ResultSet rs = st.executeQuery();
		if(!rs.isBeforeFirst())
		{
			throw new exception("entered id is not present in the table:");
		}
	    
	    Scholar scholar = null;
	    if (rs.next()) {
	        scholar = new Scholar();
	        scholar.setScholarId(rs.getInt(1));
	        scholar.setName(rs.getString("name"));
	        scholar.setMobile(rs.getString("mobile"));
	        scholar.setEmail(rs.getString("email"));
	    }

	   // rs.close();
	   // st.close();
	 //   con.close();
	    
	    return scholar;
		
		
	}
	public void UpdateScholarEmail(Integer scholarId,Scholar scholar) throws ClassNotFoundException, SQLException, exception
	{
		Connection con=getConnection.getConnections();
		//Statement st=con.createStatement();
		//ResultSet rs=st.executeQuery("select RollNo from Scholar where RollNo=()")
		PreparedStatement st=con.prepareStatement("UPDATE Scholar SET email =(?) WHERE RollNo = (?)");
		st.setString(1,scholar.getEmail());
		st.setInt(2, scholarId);
		int rs=st.executeUpdate();
		if(rs==0)
		{
			throw new exception("enter correct id:");

		}
		
	}
	
	public void DeleteScholarById(Integer scholarId) throws ClassNotFoundException, SQLException, exception
	{
		Connection con=getConnection.getConnections();
		PreparedStatement st=con.prepareStatement("DELETE FROM Scholar WHERE RollNo = (?)");
		st.setInt(1,scholarId);
		int rs=st.executeUpdate();
		if(rs==0)
		{
			throw new exception("enter correct id:");
			
		}
		
		
	}
	public void AddScholar(Scholar scholar) throws ClassNotFoundException, SQLException
	{
		Connection con=getConnection.getConnections();
		PreparedStatement st=con.prepareStatement("INSERT INTO Scholar VALUES(?,?,?,?)");
		st.setInt(1, scholar.getScholarId());
		st.setString(2,scholar.getName());
		st.setString(3,scholar.getEmail());
		st.setString(4,scholar.getMobile());
		st.execute();
		
	}
	

}
