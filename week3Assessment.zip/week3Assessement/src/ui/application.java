package ui;

import java.sql.SQLException;
import java.util.Scanner;

import customexception.exception;
import model.Scholar;
import services.service;
import services.serviceimpl;

public class application {

//	public application() {
//		// TODO Auto-generated constructor stub
//	}

	public static void main(String[] args) throws ClassNotFoundException, SQLException, exception {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		boolean something=true;
		int id=0;
		while (something) {
            System.out.println("Scholar Menu:");
            System.out.println("1. List All Scholars");
            System.out.println("2. Get One Scholar");
            System.out.println("3. Update Scholar Email");
            System.out.println("4. Delete Scholar by ID");
            System.out.println("5. Add Scholar");
            System.out.println("6. Exit");
            System.out.print("Choose an option: ");
            int choice = sc.nextInt();
            service s=new serviceimpl();
        	

            
            switch(choice)
            {
            case 1:s.ListAllScholars().stream().forEach(x->System.out.println(x));
            break;
            case 2:
            	System.out.println("enter student id");
            	 id=sc.nextInt();
            	 
            	System.out.println(s.GetOneScholar(id));
            	break;
            	
            case 3:
            	
            	System.out.println("enter student_id to update");
//            	s.GetOneScholar(id);
            	id=sc.nextInt();
            	System.out.println("enetr email to update");
            	String email=sc.next();  
            	Scholar scholar=new Scholar();
            	Scholar original=new Scholar();
            	original=s.GetOneScholar(id);
            	scholar.setScholarId(id);
            	scholar.setName(original.getName());
            	scholar.setEmail(email);
            	scholar.setMobile(original.getMobile());
            	s.UpdateScholarEmail(id, scholar);
            	break;
            case 4:
            	System.out.println("enter scholar id to delete");
            	id=sc.nextInt();
            	s.DeleteScholarById(id);
            	break;
            case 5:
            	System.out.println("enter details to add: ");
            	
            	System.out.println("enter studentid");
            	id=sc.nextInt();
            	System.out.println("enter name:");
            	String name=sc.next();
        		System.out.println("enter email:");
            	String Email=sc.next();
            	System.out.println("enter mobile number:");
            	String mobile=sc.next();
            	Scholar sco=new Scholar();
            	sco.setScholarId(id);
            	sco.setName(name);
            	sco.setEmail(Email);
            	sco.setMobile(mobile);
            	s.AddScholar(sco);
            	break;
            	
            case 6:
            	something=false;
            	break;
            
            }
            
		

	}
	}
}


