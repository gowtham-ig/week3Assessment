package customexception;

public class exception extends Exception{

	 public exception(String msg) {
		// TODO Auto-generated constructor stub
		 super(msg);
	}

}
