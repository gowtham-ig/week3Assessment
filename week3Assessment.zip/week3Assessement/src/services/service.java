package services;




import java.sql.SQLException;
import java.util.List;

import customexception.exception;
import model.Scholar;

//import module.
public interface service {
	


public List<Scholar> ListAllScholars() throws ClassNotFoundException, SQLException;
public Scholar GetOneScholar(Integer scholarId) throws ClassNotFoundException, SQLException, exception;
public void UpdateScholarEmail(Integer scholarId,Scholar scholar) throws ClassNotFoundException, SQLException, exception;
public void DeleteScholarById(Integer scholarId) throws ClassNotFoundException, SQLException, exception;
public void AddScholar(Scholar scholar) throws ClassNotFoundException, SQLException;


}
