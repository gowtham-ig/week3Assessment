package services;

import java.sql.SQLException;
import java.util.List;

import customexception.exception;
import dao.absdao;
import dao.daoimpl;
import model.Scholar;

public class serviceimpl implements service {

//	public serviceimpl() {
//		// TODO Auto-generated constructor stub
//	}
	
		


	public List<Scholar> ListAllScholars() throws ClassNotFoundException, SQLException
	{
		absdao a=new daoimpl();
		return a.ListAllScholars();
		}
	public Scholar GetOneScholar(Integer scholarId) throws ClassNotFoundException, SQLException, exception
	{
		absdao a=new daoimpl();
		return a.GetOneScholar(scholarId);
		
	}
	public void UpdateScholarEmail(Integer scholarId,Scholar scholar) throws ClassNotFoundException, SQLException, exception
	{
		absdao a=new daoimpl();
		a.UpdateScholarEmail(scholarId, scholar);
	}
	public void DeleteScholarById(Integer scholarId) throws ClassNotFoundException, SQLException, exception
	{
		absdao a=new daoimpl();
		a.DeleteScholarById(scholarId);
	}
	public void AddScholar(Scholar scholar) throws ClassNotFoundException, SQLException
	{
		absdao a=new daoimpl();
		a.AddScholar(scholar);
	}


	}



