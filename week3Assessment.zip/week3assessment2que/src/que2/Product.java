package que2;

import java.time.LocalDate;
import java.util.ArrayList;

public class Product {

    public Product(Integer id, String name, String type, Double qty, Double price, LocalDate expiryDate, Supplier supplier) {
        super();
        this.id = id;
        this.name = name;
        this.type = type;
        this.qty = qty;
        this.price = price;
        this.expiryDate = expiryDate;
        this.supplier = supplier;
    }

    Integer id;
    String name;
    String type; // ex: dairy, pulses, spices, oils, snacks
    Double qty;
    Double price;
    LocalDate expiryDate;
    Supplier supplier;

    public ArrayList<Product> getList() {
        ArrayList<Product> lis1 = new ArrayList<>();
        lis1.add(new Product(1, "milk", "dairy", 1.00, 75.00, LocalDate.of(2025, 3, 3), new Supplier(1, "rajesh")));
        lis1.add(new Product(2, "rice", "pulses", 5.00, 200.00, LocalDate.of(2025, 3, 12), new Supplier(2, "mahesh")));
        lis1.add(new Product(3, "salt", "spices", 1.00, 20.00, LocalDate.of(2025, 7, 15), new Supplier(3, "ntr")));
        lis1.add(new Product(4, "oil", "oils", 1.00, 150.00, LocalDate.of(2025, 6, 10), new Supplier(4, "prabhas")));
        lis1.add(new Product(5, "chips", "snacks", 2.00, 50.00, LocalDate.of(2025, 4, 25), new Supplier(5, "adivishesh")));
        return lis1;
    }

	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", type=" + type + ", qty=" + qty + ", price=" + price
				+ ", expiryDate=" + expiryDate + ", supplier=" + supplier + "]";
	}
    
}
