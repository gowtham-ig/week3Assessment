package que2;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Map;
import java.util.stream.Collectors;

public class producttest {

    public static void main(String[] args) {
        Product productInstance = new Product(0, null, null, 0.0, 0.0, null, null);
        ArrayList<Product> p = productInstance.getList();
        LocalDate today = LocalDate.now();

        p.stream()
         .max(Comparator.comparingDouble(x -> x.price))
         .ifPresent(x -> System.out.println(x.price));

        p.stream()
         .min(Comparator.comparingDouble(x -> x.price))
         .ifPresent(x -> System.out.println(x.price));

        p.stream()
         .filter(x -> x.expiryDate.isBefore(today))
         .forEach(x -> System.out.println(x.name));

        p.stream()
         .filter(x -> x.expiryDate.isAfter(today) && x.expiryDate.isBefore(today.plusDays(10)))
         .map(x -> x.name)
         .forEach(System.out::println);

        Map<String, Long> productTypeCounts = p.stream()
                                               .collect(Collectors.groupingBy(x -> x.type, Collectors.counting()));
        productTypeCounts.forEach((type, count) -> System.out.println(type + ": " + count));

        Map<String, Long> supplierCounts = p.stream()
                                            .collect(Collectors.groupingBy(x -> x.supplier.getSname(), Collectors.counting()));
        supplierCounts.forEach((supplier, count) -> System.out.println(supplier + ": " + count));
    }
}
